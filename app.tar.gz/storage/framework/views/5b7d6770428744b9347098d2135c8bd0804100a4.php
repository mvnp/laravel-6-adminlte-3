<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EVO BRINDES | BI System</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">
    <style>
        .text-small-gray {
            padding: 0;
            margin: 0;
            font-size: 13px;
            color: #b3b3b3;
            line-height: 1;
        }
        html, body {
            height: 100%;
            margin: 0px;
        }
    </style>
</head>
<?php /**PATH C:\_Projects\_bievo\bievo\resources\views/layouts/head.blade.php ENDPATH**/ ?>