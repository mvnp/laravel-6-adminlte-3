<!-- Control Sidebar -->
<!-- Control sidebar content goes here -->
<aside class="control-sidebar control-sidebar-dark"></aside>
<?php /**PATH C:\_Projects\_bievo\bievo\resources\views/layouts/aside.blade.php ENDPATH**/ ?>