<aside class="main-sidebar sidebar-dark-primary elevation-4">
	<!-- Brand Logo -->
	<a href="https://evobrindes.com.br/bievo" class="brand-link">
	    <img src="<?php echo e(asset('assets/dist/img/AdminLTELogo.png')); ?>" alt="EVOBRINDES Brindes" class="brand-image img-circle elevation-3" style="opacity: .8">
	    <span class="brand-text font-weight-light">AdminLTE 3</span>
	</a>
	<!-- Sidebar -->
	<div class="sidebar">
		<!-- Sidebar user (optional) -->
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="image">
				<img src="<?php echo e(asset('assets/dist/img/evo.png')); ?>" class="img-circle elevation-2" alt="<?php echo e(\Auth::user()->first_name); ?>" />
			</div>
			<div class="info">
				<a href="#" class="d-block"><?php echo e(\Auth::user()->first_name); ?></a>
			</div>
		</div>
		<!-- SidebarSearch Form -->
		
		<!-- Sidebar Menu -->
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
				<li class="nav-item">
					
					<a href="<?php echo e(route('home.users')); ?>" class="nav-link">
						<i class="fas fa-circle nav-icon"></i>
						<p>Usuários</p>
					</a>
				</li>
                <li class="nav-item">
                    <a href="<?php echo e(route('content.index')); ?>" class="nav-link">
						<i class="fas fa-circle nav-icon"></i>
						<p>Painel BI</p>
					</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout.perform')); ?>" class="nav-link">
						<i class="fas fa-circle nav-icon"></i>
						<p>Sair</p>
                    </a>
                </li>
				<!-- Add icons to the links using the .nav-icon class
					with font-awesome or any other icon font library -->
				
				
			</ul>
		</nav>
		<!-- /.sidebar-menu -->
	</div>
	<!-- /.sidebar -->
</aside>
<?php /**PATH C:\_Projects\_bievo\bievo\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>