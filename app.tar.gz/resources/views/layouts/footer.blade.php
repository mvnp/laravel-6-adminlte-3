<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Versão</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2021-2022 <a href="https://evobrindes.com.br/bievo">EVO BRINDES</a>.</strong> Todos direitos reservados.
</footer>
